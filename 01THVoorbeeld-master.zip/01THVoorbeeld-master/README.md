# 01THVoorbeeld
Plaats je eerste webpagina OnLine. Volg hiervoor de instructies op:       
[Publiceren via GitHub](https://developer.mozilla.org/nl/docs/Learn/Getting_started_with_the_web/Publicatie_website#Publiceren_via_GitHub).
